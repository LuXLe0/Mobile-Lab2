import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View, SafeAreaView, ScrollView, TextInput, Button } from 'react-native';
import ToDoList from './ToDoList';
import ToDoForm from './ToDoForm';

export default function App() {
  // Initialize the state with the given tasks array
  const [tasks, setTasks] = useState(['Do laundry', 'Go to gym', 'Walk dog']);

  return (
    <SafeAreaView style={styles.container}>
      {/* Removed ScrollView, TextInput, and Button from here to avoid duplication */}
      {/* Pass the tasks state as props to ToDoList */}
      <ToDoList tasks={tasks} />
      <ToDoForm />
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  // Additional styles if needed
});
